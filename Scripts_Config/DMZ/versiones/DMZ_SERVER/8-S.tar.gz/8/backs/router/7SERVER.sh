#! /bin/bash

echo 'script inicialitzar client'

# afegir les ips i adreça més nom a etc host 
# en un script seria ->


# 1r
echo ' 1 
'

echo '
192.168.3.100	www.gsx.ct	 general defecte
192.168.3.100	www.cataleg.gsx.ct	cataleg
192.168.3.100	www.productes.gsx.ct	productes
192.168.3.200	www.botiga.gsx.ct	botiga
172.17.3.2	www.intranet.gsx	intranet
' > /tmp/a
more /etc/hosts >> /tmp/a

more /tmp/a > /etc/hosts	# afegir lo addreça


# 2n afegir adreçes de interficie virtual
echo ' 2 
'

ifconfig eth0:0 192.168.3.100 netmask 255.255.255.0
ifconfig eth0:2 172.17.3.100 netmask 255.255.0.0
ifconfig eth0:1 192.168.3.200 netmask 255.255.255.0


# 3r matar el network manager

ps aux | grep Manager # mirar si existeix

./mata_automatic.sh 


# 4t configurar la pagina web
	# configurar les webs catàleg i productes amb accés basat en noms
	# cadascun en directoris diferents
	# els activem i comprovem que funcionen 
# podem fer la prova amb un:
firefox www.cataleg.gsx.ct

service apache2 start

cd /etc/apache2/sites-availeble/default # cal copiarho al la carpeta /etc/www/

more /etc/apache2/sites-available/default > /etc/apache2/sites-available/cataleg
more /etc/apache2/sites-available/default > /etc/apache2/sites-available/productes

# cal modificar el text manualment o pergarli una versió o les carpetes guardades en el directori descrit i després activarlos.

# també cal crear els directoris on hi allotjarem el contingut de la pagina web
sudo mkdir /var/productes
sudo mkdir /var/cataleg

# ara caldria posar les webs en marxa i després introduirli contingut
sudo service apache2 reload




sudo a2ensite cataleg
sudo a2ensite productes

# executar el script de crear usuaris...
sudo ./createUserMyWeb.sh zappa rahuy
# 4 ->

echo '
root@DS:/home/s# sudo find / -name dir.conf
/etc/apache2/mods-available/dir.conf
/etc/apache2/mods-enabled/dir.conf
root@DS:/home/s# sudo find / -name userdir.conf
/etc/apache2/mods-available/userdir.conf
root@DS:/home/s# 
'





