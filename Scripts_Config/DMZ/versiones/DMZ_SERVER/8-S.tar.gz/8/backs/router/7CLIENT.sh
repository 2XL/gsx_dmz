#! /bin/bash



# 1r afegir manualment

echo '192.168.3.100 www.gsx.ct general defecte
192.168.3.100 www.cataleg.gsx.ct cataleg
192.168.3.100 www.productes.gsx.ct productes
192.168.3.200 www.botiga.gsx.ct botiga
172.17.3.2 www.intranet.gsx intranet' # >> /etc/hosts

# 2n afegir les adreçes virtuals

ifconfig eth0:0 192.168.3.100 netmask 255.255.255.0
ifconfig eth0:1 192.168.3.200 netmask 255.255.255.0
ifconfig eth0:2 172.17.3.100 netmask 255.255.0.0

# ifconfig eth0:1 down <-- disible virtual addresss

# 3r matar el network manager

ps aux | grep Manager # mirar si existeix

./mata_automatic.sh 

# ha sigut necesari afegir manualment les IPs de la xarxa local a les tauls de routing. Per exemple:
sudo route add -net 192.168.3.0/24 gw 192.168.147.139 dev eth0




