#! /bin/bash

echo 'run as super!'

ifconfig # eth2 es el que es troba actiu
# inet addr:10.21.6.5  <- ip



echo '192.168.3.100 www.gsx.ct general defecte
192.168.3.100 www.cataleg.gsx.ct cataleg
192.168.3.100 www.productes.gsx.ct productes
192.168.3.200 www.botiga.gsx.ct botiga
172.17.3.2 www.intranet.gsx intranet' # >> /etc/hosts


# milax@d605:/$ sudo find / -name www -type d
# /usr/share/tinymce/www
# /usr/share/collabtive/www
# /var/www
# /var/lib/android/sources/android-16/org/apache/harmony/luni/tests/internal/net/www

ifconfig eth2:0 192.168.3.10 netmask 255.255.255.0
ifconfig eth2:1 172.17.3.10 netmask 255.255.0.0


# ps aux | grep Manager # kill -9 el pid del NetworkManager i dhclient
./mata_automatic.sh


#En cas de necessitat es podria afegir manualment 
#les IPs de la xarxa local a les taules de routing. 
#Per exemple:
#route add -net 192.168.1.0/24 gw 10.x.y.z dev ethX

echo ' desde el client 
milax@d620:~$ ping www.cataleg.gsx.ct
PING www.cataleg.gsx.ct (192.168.3.100) 56(84) bytes of data.
64 bytes from www.gsx.ct (192.168.3.100): icmp_req=1 ttl=64 time=1.14 ms
64 bytes from www.gsx.ct (192.168.3.100): icmp_req=2 ttl=64 time=0.501 ms
64 bytes from www.gsx.ct (192.168.3.100): icmp_req=3 ttl=64 time=0.364 ms
64 bytes from www.gsx.ct (192.168.3.100): icmp_req=4 ttl=64 time=0.492 ms
64 bytes from www.gsx.ct (192.168.3.100): icmp_req=5 ttl=64 time=0.361 ms
64 bytes from www.gsx.ct (192.168.3.100): icmp_req=6 ttl=64 time=0.496 ms
64 bytes from www.gsx.ct (192.168.3.100): icmp_req=7 ttl=64 time=0.524 ms
64 bytes from www.gsx.ct (192.168.3.100): icmp_req=8 ttl=64 time=0.527 ms
64 bytes from www.gsx.ct (192.168.3.100): icmp_req=9 ttl=64 time=0.510 ms
^Z
[1]+  Aturat                  ping www.cataleg.gsx.ct
milax@d620:~$ firefox www.cataleg.gsx.ct
'
# firefox www.cataleg.gsx.ct It works!

echo '
S`està connectant a www.cataleg.gsx.ct (www.cataleg.gsx.ct)|192.168.3.100|:80...connectat.
HTTP: sha enviat la petició, s`està esperant una resposta...200 OK
Mida: 72 [text/html]
S`està desant a: «index.html.1»

100%[======================================>] 72          --.-K/s   en 0s      

2013-04-15 11:25:21 (9,70 MB/s) - s`ha desat «index.html.1» [72/72]

milax@d620:~/Escriptori$ 
'


