#! /bin/bash

# pegar los fitxers a home/~/Desktop... directory /

[ ! `whoami` = 'root' ] && echo 'u have to run me as root!' && exit 1
# 1r afegir manualment
: <<'TEST'
	echo '192.168.3.100 www.gsx.ct general defecte
	192.168.3.100 www.cataleg.gsx.ct cataleg
	192.168.3.100 www.productes.gsx.ct productes
	192.168.3.200 www.botiga.gsx.ct botiga
	172.17.3.2 www.intranet.gsx intranet' # >> /etc/hosts
TEST

#####################################################################
rm /etc/hosts
cp FILES/hosts /etc/hosts	# copiar les adresçes i enllaços
#####################################################################

# 2n afegir les adreçes virtuals
#####################################################################
: << 'SERVER_ONLY'
ifconfig eth2:0 192.168.3.100 netmask 255.255.255.0	# crear els virtual hosts ports xD
ifconfig eth2:1 192.168.3.200 netmask 255.255.255.0	#
ifconfig eth2:2 172.17.3.2 netmask 255.255.0.0	#
#####################################################################
# ifconfig eth0:1 down <-- disible virtual addresss
SERVER_ONLY
# 3r matar el network manager

ps aux | grep Manager # mirar si existeix
./mata_automatic.sh # dir sisi


if [ $# -eq 1 ]
then
ethX=$1
eth_ip=$(ifconfig $ethX | sed -n '2p' | cut -c 21-35)
echo $eth_ip
# ha sigut necesari afegir manualment les IPs de la xarxa local a les tauls de routing. Per exemple:
route add -net 192.168.3.0/24 gw $eth_ip dev $ethX #this is optional depending on machine config and router
fi




