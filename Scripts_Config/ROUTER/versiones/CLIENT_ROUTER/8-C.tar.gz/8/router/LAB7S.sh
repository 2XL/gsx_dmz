#! /bin/bash

echo 'preliminar'
tail -f /var/log/apache2/error.log
tail -f /var/log/apache2/acces.log



echo ' uv to run as super!'

echo '192.168.3.100 www.gsx.ct general defecte
192.168.3.100 www.cataleg.gsx.ct cataleg
192.168.3.100 www.productes.gsx.ct productes
192.168.3.200 www.botiga.gsx.ct botiga
172.17.3.2 www.intranet.gsx intranet' # >> /etc/hosts








ifconfig eth2:0 192.168.3.100 netmask 255.255.255.0
ifconfig eth2:1 192.168.3.200 netmask 255.255.255.0
ifconfig eth2:2 172.17.3.10 netmask 255.255.0.0



echo 'init server apache2'
sudo service apache2 start
echo '?'
cd /etc/apache2/sites-available
more default
#hacer una copia del default en la misma carpeta con el nombre cataleg
#meterle el contenido que sale abajo
sudo a2ensite cataleg
sudo service apache2 reload

sudo mkdir /var/www/cataleg
# falta modificar 
# :sy on -> activar colors

echo '
milax@d606:/etc/apache2/sites-available$ more cataleg 
<VirtualHost *:80>
	ServerAdmin webmaster@localhost
	ServerName www.cataleg.gsx.ct
	DocumentRoot /var/www/cataleg
	<Directory />
		Options FollowSymLinks
		AllowOverride None
	</Directory>
	<Directory /var/www/cataleg>
		Options Indexes FollowSymLinks MultiViews
		AllowOverride None
		Order allow,deny
		allow from all
	</Directory>

	ScriptAlias /cgi-bin/ /usr/lib/cgi-bin/
	<Directory "/usr/lib/cgi-bin">
		AllowOverride None
		Options +ExecCGI -MultiViews +SymLinksIfOwnerMatch
		Order allow,deny
		Allow from all
	</Directory>

	ErrorLog ${APACHE_LOG_DIR}/error.log

	# Possible values include: debug, info, notice, warn, error, crit,
	# alert, emerg.
	LogLevel warn

	CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
'


echo '
// compte amnb networkman etc...

root@d621:/etc/apache2/sites-available# w3m -dump www.cataleg.gsx.ct
It works!

for paco en gato

'


