#! /bin/bash

echo ' ROUTER 

eth2      Link encap:Ethernet  HWaddr 00:1a:92:77:70:f4  
          inet addr:10.21.6.6

'

# conectar cables mirar quina targeta... 
sudo ifconfig eth1 172.18.0.1 netmask 255.254.0.0


# matar los network deamons







