#! /bin/bash

echo ' ROUTER 

eth2      Link encap:Ethernet  HWaddr 00:1a:92:77:70:f4  
          inet addr:10.21.6.6

'
[ `whoami` = 'root' ] || exit 1
if [ $# -eq 0 ]
then
ethX=$(mii-tool | head -n1 | cut -c1-4)
else
ethX=$1
fi
 
# conectar cables mirar quina targeta... 
# se pasara per parametre ela targe o manual
ifconfig $ethX 192.168.1.124 netmask 255.255.255.0  
ifconfig $ethX:0 172.18.0.124 netmask 255.254.0.0  
# ifconfig $ethX:1 172.20.0.124 netmask 255.254.0.0 

######################################################
echo ' resetejar /etc/hosts
'
rm /etc/hosts
cp FILES/hosts /etc/



# mascara 172.16+8+4+2/15
# 172.30/15
# subneting 0.00000000.00000000 
# 1r # 172.18.0.1 --> intranet general
# 2n # 172.18.0.2 --> servidor

# sudo iptables -L -nv -t nat
# matar los network deamons
./mata_automatic.sh
# enable forewarding
echo "1" > /proc/sys/net/ipv4/ip_forward
sysctl -p /etc/sysctl.conf
# postrouting --> donar acces internet al servidor

iptables -t nat -A POSTROUTING -o eth2 -j MASQUERADE
# iptables -t nat -A POSTROUTING -p tcp -o eth0 -j SNAT --to-source 192.168.1.0-194.236.50.160:1024-32000
iptables -t nat -A POSTROUTING -s 192.168.147/24 -d 0/0 -o eth2 -j MASQUERADE


service apache2 restart
